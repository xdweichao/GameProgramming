﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Player : MonoBehaviour
{

    public GameObject ProjectileRock;
    public GameObject ProjectilePaper;
    public GameObject ProjectileScissor;
    private GameObject cloneProj;
    public int direction = 4;
    public float bulletspeed = 5;
    private GameObject Projectile;
  

    public float fireRate;
    private float nextFire;

    public AudioClip RockSound;
    public AudioClip PaperSound;
    public AudioClip ScissorSound;
    private AudioSource source;

    void Awake()
    {
        source = GetComponent<AudioSource>();
    }

    void Update()
    {


        // Rotate Player to face direction
        if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
            transform.LookAt(new Vector3(0, 0, -90));
            direction = 3;
            }
        if (Input.GetKeyDown(KeyCode.RightArrow))
            { 
            transform.LookAt(new Vector3(0, 0, 90));
            direction = 4;
            }
        if (Input.GetKeyDown(KeyCode.UpArrow))
            { 
            LookUp();
            direction = 1;
            }
        if (Input.GetKeyDown(KeyCode.DownArrow))
            { 
            LookDown();
            direction = 2;
            }


        //Get Input and change projectiles

        if (Input.GetKeyDown(KeyCode.A))
        {
            Projectile = ProjectileRock;
            source.PlayOneShot(RockSound);
            Shoot();
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            Projectile = ProjectilePaper;
            source.PlayOneShot(PaperSound);
            Shoot();
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            Projectile = ProjectileScissor;
            source.PlayOneShot(ScissorSound);
            Shoot();
        }

    }




    void LookUp()
    {
        transform.LookAt(new Vector3(0, 0, 90));
        transform.Rotate(new Vector3(0, 0, 90)); 
    }

    void LookDown()
    {
        transform.LookAt(new Vector3(0, 0, 90));
        transform.Rotate(new Vector3(0, 0, -90));
    }

    void Shoot()
    {
        //cdr for fire rate
        if (Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            
            //Rotate Projectiles and shoot it
            GameObject bulletInstance = Instantiate(Projectile, transform.position, Quaternion.Euler(new Vector3(0, 0, 0))) as GameObject;
            Rigidbody2D rigidbody = bulletInstance.GetComponent<Rigidbody2D>();

            //rotate bulletInstance
            if (direction == 1)
            {
                bulletInstance.transform.LookAt(new Vector3(0, 0, 90));
                bulletInstance.transform.transform.Rotate(new Vector3(0, 0, 90));
                rigidbody.velocity = (Vector2.up * bulletspeed);
            }
            else if (direction == 2)
            {
                bulletInstance.transform.LookAt(new Vector3(0, 0, 90));
                bulletInstance.transform.transform.Rotate(new Vector3(0, 0, -90));
                rigidbody.velocity = (Vector2.down * bulletspeed);
            }
            else if (direction == 3)
            {
                bulletInstance.transform.LookAt(new Vector3(0, 0, -90));
                rigidbody.velocity = (Vector2.left * bulletspeed);
            }
            else if (direction == 4)
            {
                bulletInstance.transform.LookAt(new Vector3(0, 0, 90));
                rigidbody.velocity = (Vector2.right * bulletspeed);
            }
        }
    }

}