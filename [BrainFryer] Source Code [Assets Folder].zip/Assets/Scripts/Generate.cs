﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generate : MonoBehaviour
{
    private GameObject RandomHand;
    private float number;
    public GameObject RockHand;
    public GameObject PaperHand;
    public GameObject ScissorHand;



    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("randomTime", 1f, 2f);
    }
    


    void CreateObstacle()
    {
        float number = Random.Range(0, 3);
        //let projectiles appear on attached object
        if (number == 2)
        {
            RandomHand = ScissorHand;
        }
        else if (number == 1)
        {
            RandomHand = PaperHand;
        }
        else if (number == 0)
        {
            RandomHand = RockHand;
        }
        Instantiate(RandomHand, transform.position, transform.rotation);

        
    }


    void randomTime() {
        if (Random.Range(0, 2) == 0) 
        {
            CreateObstacle();
        }
    }


    // Update is called once per frame
    void Update()
    {



    }
}
