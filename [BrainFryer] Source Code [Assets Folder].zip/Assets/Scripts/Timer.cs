﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    public Text TimerText;
    public float ScoreTime;
    public float niceTime;
    // Update is called once per frame


    void Update()
    {
        ScoreTime += Time.deltaTime;
        int minutes = Mathf.FloorToInt(ScoreTime / 60F);
        int seconds = Mathf.FloorToInt(ScoreTime - minutes * 60);
        string niceTime = string.Format("{0:0}:{1:00}", minutes, seconds);
        TimerText.text = niceTime;
        PlayerPrefs.SetString("PlayerScore", niceTime);
    }
}

