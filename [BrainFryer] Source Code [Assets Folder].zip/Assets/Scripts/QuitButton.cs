﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class QuitButton : MonoBehaviour
{
    public Button Quit;

    void Start()
    {

        Quit.onClick.AddListener(Die);
    }

    void Die()
    {
        SceneManager.LoadScene("GameOver", LoadSceneMode.Single);
    }
}
