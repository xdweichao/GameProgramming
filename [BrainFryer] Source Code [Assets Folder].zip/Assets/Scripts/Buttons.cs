﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Buttons : MonoBehaviour
{
    public Button Easy;
    public Button Normal;
    public Button Hard;
    public Button Hell;
    public Button Nightmare;

    void Start()
    {
        //Calls the TaskOnClick/TaskWithParameters/ButtonClicked method when you click the Button
        Easy.onClick.AddListener(EasyMode);
        Normal.onClick.AddListener(NormalMode);
        Hard.onClick.AddListener(HardMode);
        Hell.onClick.AddListener(HellMode);
        Nightmare.onClick.AddListener(NightmareMode);
    }

    void EasyMode()
    {
        SceneManager.LoadScene("Easy", LoadSceneMode.Single);
    }
    void NormalMode()
    {
        SceneManager.LoadScene("Normal", LoadSceneMode.Single);
    }
    void HardMode()
    {
        SceneManager.LoadScene("Hard", LoadSceneMode.Single);
    }
    void HellMode()
    {
        SceneManager.LoadScene("Hell", LoadSceneMode.Single);
    }
    void NightmareMode()
    {
        SceneManager.LoadScene("Nightmare", LoadSceneMode.Single);
    }




}
