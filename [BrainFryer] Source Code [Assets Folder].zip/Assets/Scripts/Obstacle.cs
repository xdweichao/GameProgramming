﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Obstacle : MonoBehaviour
{
    public Rigidbody2D rgbody;
    public Vector2 velocity = new Vector2(1, 0);
    // Start is called before the first frame update
    void Start()
    {
        rgbody = GetComponent<Rigidbody2D>();
        rgbody.velocity = velocity;
        transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z);
    }


    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Die();
        }
        if (collision.gameObject.tag == "ProR" && this.gameObject.tag =="IncomingS")
        {
            Destroy(this.gameObject);
            Destroy(collision.gameObject);
        } else
        {
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.tag == "ProS" && this.gameObject.tag == "IncomingP")
        {
            Destroy(this.gameObject);
            Destroy(collision.gameObject);
        }
        else
        {
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.tag == "ProP" && this.gameObject.tag == "IncomingR")
        {
            Destroy(this.gameObject);
            Destroy(collision.gameObject);
        }
        else
        {
            Destroy(collision.gameObject);
        }

}


    void Die()
    {
        SceneManager.LoadScene("GameOver", LoadSceneMode.Single);
    }




}