﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GOButtons : MonoBehaviour
{

    public Button MainMenu;

    void Start()
    {
     
        MainMenu.onClick.AddListener(MainMode);
    }
    
    void MainMode()
    {
        SceneManager.LoadScene("MainMenu", LoadSceneMode.Single);
    }




}
