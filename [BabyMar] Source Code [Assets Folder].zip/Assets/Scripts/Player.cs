﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public Rigidbody2D rgbody;
    public Vector2 jumpForce = new Vector2 (0,200);
    int score = 0;


    void Start()
    {
        rgbody = GetComponent<Rigidbody2D>();
    }

    void OnGUI()
    {
        GUI.color = Color.black;
        GUILayout.BeginArea(new Rect(Screen.width / 2, Screen.height / 2, 80, 30));
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label("Score: " + score.ToString());
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.EndArea();

    }



    void OnTriggerEnter2D(Collider2D collision)
    {
        score++;
        source.PlayOneShot(scoreSound);
    }


    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) {
            rgbody.velocity = Vector2.zero;
            rgbody.AddForce(jumpForce);
        }


        Vector2 screenPosition = Camera.main.WorldToScreenPoint(transform.position);
        if (screenPosition.y > Screen.height || screenPosition.y < 0)
        {
            Die();
        }


    }
    
    void OnCollisionEnter2D(Collision2D collision)
    {
        Die();
    }


    void Die()
    {
        Application.LoadLevel(Application.loadedLevel);
    }


    public AudioClip scoreSound;
    private AudioSource source;

    void Awake()
    {
        source = GetComponent<AudioSource>();
    }


}
